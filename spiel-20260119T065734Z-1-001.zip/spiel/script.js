// =========================================================
// 1. DOM-Elemente abrufen & Sounds
// =========================================================
const keksZaehler = document.getElementById('keks-zaehler');
const kpsAnzeige = document.getElementById('kps-anzeige');
const kpsTooltip = document.getElementById('kps-tooltip');
const klickkraftAnzeige = document.getElementById('klickkraft-anzeige');
const prestigeBonusAnzeige = document.getElementById('prestige-bonus-anzeige'); 
const hauptKeks = document.getElementById('haupt-keks');
const speichernButton = document.getElementById('speichern-button');
const resetButton = document.getElementById('reset-button');
const prestigeButton = document.getElementById('prestige-button'); 
const achievementsBereich = document.getElementById('achievements-bereich');
const goldenerKeksButton = document.getElementById('goldener-keks'); 
const activeBuffsList = document.getElementById('active-buffs-list');
const questBereich = document.getElementById('quest-bereich'); 

const klickSound = document.getElementById('klick-sound');
const kaufSound = document.getElementById('kauf-sound');


// =========================================================
// 2. Spielvariablen & Konstanten definieren
// =========================================================
let kekse = 0;
let klickkraft = 1;
let kekseProSekunde = 0;
let kpsMultiplikator = 1; 

// Passive Forschung / Offline
let lastSaveTime = Date.now(); 

// Prestige-Variablen
let prestigeKekse = 0;
const PRESTIGE_SCHWELLE = 1000000; 
const PRESTIGE_BONUS_PRO_KEKS = 0.05; 
let prestigeBonus = 0;

// KPS-Quellen
let kpsQuellen = { oma: 0, fabrik: 0 };

// Upgrade Definitionen
const basisUpgrades = {
    maus: { basisKosten: 15, kosten: 15, anzahl: 0, wirkung: 2, kostenSteigerung: 1.15, },
    oma: { basisKosten: 100, kosten: 100, anzahl: 0, kps: 1, kostenSteigerung: 1.15, },
    fabrik: { basisKosten: 1000, kosten: 1000, anzahl: 0, kps: 10, kostenSteigerung: 1.15, },
    wissenschaftler: { basisKosten: 5000, kosten: 5000, anzahl: 0, kpsMultiplikatorWert: 2, kostenSteigerung: 1, istEinmalig: true, }
};
let upgrades = JSON.parse(JSON.stringify(basisUpgrades)); 

// Buff Definitionen
const buffDefinitions = {
    klickFieber: { id: 'klickFieber', name: 'Klick-Fieber (+500% Klickkraft)', kosten: 2000, dauer: 60, klickBonus: 5, kpsBonus: 0 },
    kpsTurbo: { id: 'kpsTurbo', name: 'KPS-Turbo (+100% KPS)', kosten: 10000, dauer: 120, klickBonus: 0, kpsBonus: 1 },
};
let activeBuffs = []; 

// Quest Definitionen
const questDefinitions = [
    { id: 'klick_100', name: 'Klicke 100 Mal', bedingung: 100, typ: 'klicks', belohnung: 500 },
    { id: 'kauf_oma_3', name: 'Besitze 3 Omas', bedingung: 3, typ: 'upgrade_anzahl', upgradeId: 'oma', belohnung: 2500 },
    { id: 'kps_100', name: 'Erreiche 100 KPS', bedingung: 100, typ: 'kps_wert', belohnung: 10000 },
];
let aktiveQuest = null;


// Errungenschaften
const allAchievements = [
    { id: 'start', name: 'Der erste Klick', bedingung: 10, typ: 'kekse' },
    { id: '1k', name: 'Tausendär', bedingung: 1000, typ: 'kekse' },
    { id: '10k', name: 'Zehntausend Kekse', bedingung: 10000, typ: 'kekse' },
    { id: 'oma', name: 'Oma-Power', bedingung: 1, typ: 'upgrade', upgradeId: 'oma' },
    { id: 'fabrik_kauf', name: 'Industrieller', bedingung: 1, typ: 'upgrade', upgradeId: 'fabrik' },
    { id: 'wissenschaftler_kauf', name: 'Keks-Nobelpreisträger', bedingung: 1, typ: 'upgrade', upgradeId: 'wissenschaftler' },
    { id: 'prestige_erster', name: 'Der Aufstieg', bedingung: 1, typ: 'prestige' },
];
let freigeschalteteAchievements = [];
let totalKlicks = 0; 


// Geheimer Cheat-Code
const CHEAT_CODE_SEQUENZ = ['K', 'E', 'K', 'S'];
let cheatCodeIndex = 0;


// =========================================================
// 3. Hilfsfunktionen
// =========================================================

function kuerzeZahl(zahl) {
    if (Math.abs(zahl) < 1000) {
        return Math.floor(zahl).toLocaleString('de-DE');
    }
    const einheiten = ["", " Tsd.", " M", " Mrd.", " Bio."];
    let i = 0;
    let betrag = Math.abs(zahl);
    
    while (betrag >= 1000 && i < einheiten.length - 1) {
        betrag /= 1000;
        i++;
    }
    
    let ergebnis = betrag.toFixed(2).replace(/\.00$/, "").replace(/\.([0-9])0$/, '.$1');
    return (zahl < 0 ? '-' : '') + ergebnis + einheiten[i];
}

function spieleSound(audioElement) {
    if (audioElement) {
        audioElement.currentTime = 0;
        audioElement.play().catch(e => {}); 
    }
}


// =========================================================
// 4. Speicher- und Ladefunktionen
// =========================================================

function speichereSpiel() {
    const aktiveBuffsZumSpeichern = activeBuffs.filter(buff => buff.ende > Date.now());
    
    const spielstand = {
        kekse: kekse,
        klickkraft: klickkraft,
        kpsMultiplikator: kpsMultiplikator,
        prestigeKekse: prestigeKekse,
        upgrades: upgrades,
        freigeschalteteAchievements: freigeschalteteAchievements,
        activeBuffs: aktiveBuffsZumSpeichern,
        lastSaveTime: Date.now(), 
        totalKlicks: totalKlicks, 
        aktiveQuest: aktiveQuest
    };
    localStorage.setItem('cookieClickerSave', JSON.stringify(spielstand));
    speichernButton.textContent = 'Gespeichert! ✅';
    setTimeout(() => { speichernButton.textContent = 'Spiel speichern'; }, 1500);
}

function ladeSpiel() {
    const gespeicherterStand = localStorage.getItem('cookieClickerSave');
    if (!gespeicherterStand) {
        berechnePrestigeBonus(); 
        setzeNeueQuest(); 
        return; 
    }
    
    const stand = JSON.parse(gespeicherterStand);

    kekse = stand.kekse || 0;
    klickkraft = stand.klickkraft || 1;
    kpsMultiplikator = stand.kpsMultiplikator || 1; 
    prestigeKekse = stand.prestigeKekse || 0;
    freigeschalteteAchievements = stand.freigeschalteteAchievements || [];
    totalKlicks = stand.totalKlicks || 0; 

    if (stand.activeBuffs) {
         activeBuffs = stand.activeBuffs.filter(buff => buff.ende > Date.now());
    }

    if (stand.upgrades) {
        for (const id in stand.upgrades) {
            if (upgrades[id]) {
                upgrades[id].anzahl = stand.upgrades[id].anzahl;
                upgrades[id].kosten = stand.upgrades[id].kosten;
            }
        }
    }

    // Passive Forschung berechnen 
    if (stand.lastSaveTime) {
        lastSaveTime = stand.lastSaveTime;
        berechneOfflineEinkommen(); 
    }
    
    // Quest laden 
    aktiveQuest = stand.aktiveQuest || null;
    if (!aktiveQuest || aktiveQuest.abgeschlossen) setzeNeueQuest();
    

    berechnePrestigeBonus(); 
    berechneGesamtWerte();
    aktualisiereAnzeigen();
    aktualisiereAchievementsAnzeige();
    aktualisiereBuffAnzeige();
    aktualisiereQuestAnzeige();
}

function berechneKpsOhneTemporaereBuffs() {
     // Berechnung der KPS nur basierend auf Permanenten Upgrades, Prestige und Wissenschaftler
    const basisKPS = upgrades.oma.anzahl * upgrades.oma.kps + upgrades.fabrik.anzahl * upgrades.fabrik.kps;
    let kpsNachPrestige = basisKPS * (1 + prestigeBonus);
    
    return kpsNachPrestige * kpsMultiplikator;
}

function berechneOfflineEinkommen() {
    const zeitDifferenzMs = Date.now() - lastSaveTime;
    const zeitDifferenzSekunden = zeitDifferenzMs / 1000;
    
    // Offline-Produktion ist 50% der aktuellen KPS
    const kpsBeimSpeichern = berechneKpsOhneTemporaereBuffs(); 
    const offlineKekse = Math.floor(kpsBeimSpeichern * zeitDifferenzSekunden * 0.5);
    
    // Begrenze Offline-Einkommen auf max. 48 Stunden (172800 Sekunden)
    const maxZeit = 172800; 
    
    if (zeitDifferenzSekunden > maxZeit) {
        const gekuerztesOfflineKekse = Math.floor(kpsBeimSpeichern * maxZeit * 0.5);
        if (gekuerztesOfflineKekse > 0) {
            kekse += gekuerztesOfflineKekse;
             alert(`Willkommen zurück! Du warst zu lange weg, aber hast ${kuerzeZahl(gekuerztesOfflineKekse)} Kekse (max. 48h) offline verdient.`);
        }
    } else if (offlineKekse > 0) {
        kekse += offlineKekse;
        alert(`Willkommen zurück! Du hast offline ${kuerzeZahl(offlineKekse)} Kekse verdient. (${Math.floor(zeitDifferenzSekunden / 60)} Minuten)`);
    }
    
    lastSaveTime = Date.now();
}

function resetteSpiel() {
    if (confirm("Möchtest du das Spiel wirklich zurücksetzen? Alle Fortschritte gehen verloren!")) {
        localStorage.removeItem('cookieClickerSave');
        window.location.reload(); 
    }
}

// =========================================================
// 5. Prestige-Logik
// =========================================================

function berechnePrestigeBonus() {
    prestigeBonus = prestigeKekse * PRESTIGE_BONUS_PRO_KEKS;
}

function prestigeReset() {
    const neuePrestigeKekse = Math.floor(Math.sqrt(kekse / PRESTIGE_SCHWELLE));
    
    if (neuePrestigeKekse < 1) {
        alert(`Du brauchst ${kuerzeZahl(PRESTIGE_SCHWELLE)} Kekse, um Prestige freizuschalten. Du hast ${kuerzeZahl(Math.floor(kekse))}.`);
        return;
    }

    if (confirm(`Möchtest du das Spiel zurücksetzen und ${neuePrestigeKekse} Prestige-Kekse erhalten? \n(Erhöht deine Basiswerte im nächsten Durchlauf!)`)) {
        
        prestigeKekse += neuePrestigeKekse;

        kekse = 0;
        klickkraft = 1;
        kekseProSekunde = 0;
        kpsMultiplikator = 1;
        activeBuffs = []; 
        totalKlicks = 0;
        aktiveQuest = null; 
        
        upgrades = JSON.parse(JSON.stringify(basisUpgrades));

        berechnePrestigeBonus();
        speichereSpiel();
        
        window.location.reload(); 
    }
}

// =========================================================
// 6. Errungenschafts-Logik
// =========================================================

function pruefeAchievements() {
    let neuesAchievementFreigeschaltet = false;
    
    allAchievements.forEach(ach => {
        if (freigeschalteteAchievements.includes(ach.id)) return; 

        let bedingungErfuellt = false;

        if (ach.typ === 'kekse' && kekse >= ach.bedingung) {
            bedingungErfuellt = true;
        } else if (ach.typ === 'upgrade') {
            const upgradeStatus = upgrades[ach.upgradeId];
            if (upgradeStatus && upgradeStatus.anzahl >= ach.bedingung) {
                bedingungErfuellt = true;
            }
        } else if (ach.typ === 'prestige' && prestigeKekse >= ach.bedingung) {
             bedingungErfuellt = true;
        }

        if (bedingungErfuellt) {
            freigeschalteteAchievements.push(ach.id);
            alert(`🎉 Errungenschaft freigeschaltet: ${ach.name}!`);
            neuesAchievementFreigeschaltet = true;
        }
    });

    if (neuesAchievementFreigeschaltet) {
        aktualisiereAchievementsAnzeige();
        speichereSpiel(); 
    }
}

function aktualisiereAchievementsAnzeige() {
    if (freigeschalteteAchievements.length === 0) {
        achievementsBereich.innerHTML = '<p>Noch keine Erfolge freigeschaltet.</p>';
        return;
    }
    
    achievementsBereich.innerHTML = ''; 
    
    freigeschalteteAchievements.forEach(achId => {
        const achDetails = allAchievements.find(a => a.id === achId);
        if (achDetails) {
            const div = document.createElement('div');
            div.classList.add('achievement');
            div.textContent = achDetails.name;
            achievementsBereich.appendChild(div);
        }
    });
}


// =========================================================
// 7. Quest-Logik
// =========================================================

function setzeNeueQuest() {
    const verfuegbareQuests = questDefinitions.filter(q => q.id !== (aktiveQuest ? aktiveQuest.id : null));
    
    if (verfuegbareQuests.length > 0) {
        const questIndex = Math.floor(Math.random() * verfuegbareQuests.length);
        aktiveQuest = JSON.parse(JSON.stringify(verfuegbareQuests[questIndex])); 
        aktiveQuest.aktuellerWert = 0;
        aktiveQuest.abgeschlossen = false;
        aktualisiereQuestAnzeige();
        speichereSpiel();
    } else {
        questBereich.innerHTML = '<p>Alle Quests abgeschlossen! Neue Quests folgen bald.</p>';
    }
}

function aktualisiereQuestAnzeige() {
    if (!aktiveQuest) {
        questBereich.innerHTML = '<p>Keine aktive Quest.</p><button onclick="setzeNeueQuest()">Neue Quest starten</button>';
        return;
    }
    if (aktiveQuest.abgeschlossen) {
        questBereich.innerHTML = '<p>Quest abgeschlossen! Glückwunsch! </p><button onclick="setzeNeueQuest()">Neue Quest starten</button>';
        return;
    }
    
    let fortschritt = 0;

    switch (aktiveQuest.typ) {
        case 'klicks':
            fortschritt = Math.min(totalKlicks, aktiveQuest.bedingung);
            break;
        case 'upgrade_anzahl':
            fortschritt = Math.min(upgrades[aktiveQuest.upgradeId].anzahl, aktiveQuest.bedingung);
            break;
        case 'kps_wert':
            fortschritt = Math.min(Math.floor(kekseProSekunde), aktiveQuest.bedingung);
            break;
    }
    
    aktiveQuest.aktuellerWert = fortschritt;
    
    const maxWert = aktiveQuest.bedingung;
    const prozent = (fortschritt / maxWert) * 100;
    
    questBereich.innerHTML = `
        <div class="quest-box">
            <h4>${aktiveQuest.name}</h4>
            <p>Belohnung: ${kuerzeZahl(aktiveQuest.belohnung)} Kekse</p>
            <div class="quest-progress-bar-container">
                <div class="quest-progress-bar" style="width: ${prozent}%;"></div>
            </div>
            <p>${kuerzeZahl(fortschritt)} / ${kuerzeZahl(maxWert)}</p>
            <button class="quest-abschliessen-button" onclick="versucheQuestAbschluss()" ${fortschritt >= maxWert ? '' : 'disabled'}>
                ${fortschritt >= maxWert ? 'BELOHNUNG EINFORDERN' : 'Fortschritt prüfen'}
            </button>
        </div>
    `;
}

function versucheQuestAbschluss() {
    if (!aktiveQuest || aktiveQuest.abgeschlossen) return;
    
    // Erneute Prüfung der Bedingung
    let bedingungErfuellt = false;
    
    if (aktiveQuest.typ === 'klicks' && totalKlicks >= aktiveQuest.bedingung) {
        bedingungErfuellt = true;
    } else if (aktiveQuest.typ === 'upgrade_anzahl' && upgrades[aktiveQuest.upgradeId].anzahl >= aktiveQuest.bedingung) {
        bedingungErfuellt = true;
    } else if (aktiveQuest.typ === 'kps_wert' && Math.floor(kekseProSekunde) >= aktiveQuest.bedingung) {
        bedingungErfuellt = true;
    }
    
    if (bedingungErfuellt) {
        kekse += aktiveQuest.belohnung;
        alert(`🎉 Quest abgeschlossen: ${aktiveQuest.name}! Du erhältst ${kuerzeZahl(aktiveQuest.belohnung)} Kekse.`);
        aktiveQuest.abgeschlossen = true;
        
        aktualisiereAnzeigen();
        setzeNeueQuest(); // Startet automatisch die nächste Quest
        speichereSpiel();
    } else {
        alert("Quest ist noch nicht abgeschlossen!");
    }
}

// =========================================================
// 8. Cheat-Funktionen (NUR FÜR SIE!) 🤫
// =========================================================

function cheatCode(event) {
    const key = event.key.toUpperCase();
    
    if (key === CHEAT_CODE_SEQUENZ[cheatCodeIndex]) {
        cheatCodeIndex++;
        
        if (cheatCodeIndex === CHEAT_CODE_SEQUENZ.length) {
            
            const cheatBetrag = 1000000; 
            
            kekse += cheatBetrag;
            klickkraft += 100;
            
            alert(`🤫 CHEAT AKTIVIERT! Du hast ${kuerzeZahl(cheatBetrag)} Kekse und +100 Klickkraft erhalten!`);
            
            aktualisiereAnzeigen();
            cheatCodeIndex = 0; 
        }
    } else {
        cheatCodeIndex = 0;
    }
}

window.gibMirKekse = function(menge) {
    menge = Math.max(0, menge || 1000000); 
    kekse += menge;
    alert(`Konsole: ${kuerzeZahl(menge)} Kekse hinzugefügt.`);
    aktualisiereAnzeigen();
    speichereSpiel();
}


// =========================================================
// 9. Tooltip-Logik
// =========================================================

function zeigeKpsTooltip() {
    const gesamtKPS = kekseProSekunde;
    const basisKPS = kpsQuellen.oma + kpsQuellen.fabrik;
    
    const prestigeKpsBonus = (basisKPS * prestigeBonus);
    
    const kpsBuffMulti = activeBuffs.reduce((acc, buff) => acc + buff.kpsBonus, 1);
    const totalMulti = kpsMultiplikator * kpsBuffMulti;

    let html = `
        <p><strong>KPS Quellen:</strong></p>
        <p>Omas: ${kuerzeZahl(kpsQuellen.oma)} KPS</p>
        <p>Fabriken: ${kuerzeZahl(kpsQuellen.fabrik)} KPS</p>
        <hr style="margin: 5px 0;">
        <p>Basis KPS: ${kuerzeZahl(basisKPS)} KPS</p>
        <p>Prestige Bonus (+${(prestigeBonus * 100).toFixed(1).replace('.0', '')}%): +${kuerzeZahl(prestigeKpsBonus)} KPS</p>
        <p>Multiplikator (x${totalMulti}): ${kuerzeZahl(basisKPS + prestigeKpsBonus)} KPS</p>
        <hr style="margin: 5px 0;">
        <p><strong>GESAMT: ${kuerzeZahl(gesamtKPS)} KPS</strong></p>
    `;
    
    kpsTooltip.innerHTML = html;
    kpsTooltip.style.display = 'block';
}

function versteckeKpsTooltip() {
    kpsTooltip.style.display = 'none';
}


// =========================================================
// 10. Goldenes Keks-Event
// =========================================================

let goldenesKeksTimeout;

function startGoldenesKeksEvent() {
    const zeitSpanne = Math.random() * (600000 - 300000) + 300000; 
    
    setTimeout(() => {
        zeigeGoldenenKeks();
        startGoldenesKeksEvent(); 
    }, zeitSpanne);
}

function zeigeGoldenenKeks() {
    if (kekseProSekunde <= 0 && kekse < 100) return; 
    
    goldenerKeksButton.style.display = 'block';
    
    const x = Math.random() * (window.innerWidth - 200);
    const y = Math.random() * (window.innerHeight - 200);
    
    goldenerKeksButton.style.left = `${x}px`;
    goldenerKeksButton.style.top = `${y}px`;
    
    goldenesKeksTimeout = setTimeout(() => {
        goldenerKeksButton.style.display = 'none';
    }, 10000);
}

function klickeGoldenenKeks() {
    goldenerKeksButton.style.display = 'none';
    clearTimeout(goldenesKeksTimeout);
    
    const chance = Math.random();
    
    if (chance < 0.9) { 
        const gewinn = Math.floor(kekseProSekunde * 600) + Math.max(100, Math.floor(kekse * 0.05));
        kekse += gewinn;
        alert(`🍀 Glücksgriff! Du gewinnst ${kuerzeZahl(gewinn)} Kekse!`);
    } else {
        const verlust = Math.floor(kekse * 0.05);
        kekse = Math.max(0, kekse - verlust);
        alert(`😭 Unglück! Du verlierst ${kuerzeZahl(verlust)} Kekse.`);
    }
    
    aktualisiereAnzeigen();
    speichereSpiel();
}

// =========================================================
// 11. Forschungszentrum & Buff Logik
// =========================================================

function kaufeBuff(buffID) {
    const buffDef = buffDefinitions[buffID];
    
    const istBereitsAktiv = activeBuffs.some(buff => buff.id === buffID);
    if (istBereitsAktiv) {
        alert(`Der Bonus "${buffDef.name}" ist bereits aktiv. Warte, bis er abgelaufen ist!`);
        return;
    }

    if (kekse >= buffDef.kosten) {
        kekse -= buffDef.kosten;
        spieleSound(kaufSound);
        
        const endeZeit = Date.now() + (buffDef.dauer * 1000);
        
        activeBuffs.push({
            id: buffID,
            name: buffDef.name,
            klickBonus: buffDef.klickBonus,
            kpsBonus: buffDef.kpsBonus,
            ende: endeZeit
        });
        
        alert(`⚡ Forschung erfolgreich! "${buffDef.name}" ist für ${buffDef.dauer} Sekunden aktiv!`);

        berechneGesamtWerte();
        aktualisiereAnzeigen();
        aktualisiereBuffAnzeige();
    }
}

function aktualisiereBuffAnzeige() {
    const jetzt = Date.now();
    activeBuffs = activeBuffs.filter(buff => buff.ende > jetzt);
    
    if (activeBuffs.length === 0) {
        activeBuffsList.innerHTML = '<p>Keine</p>';
        return;
    }
    
    activeBuffsList.innerHTML = activeBuffs.map(buff => {
        const restZeitSekunden = Math.floor((buff.ende - jetzt) / 1000);
        const minuten = Math.floor(restZeitSekunden / 60);
        const sekunden = String(restZeitSekunden % 60).padStart(2, '0');
        const zeitAnzeige = `${minuten > 0 ? minuten + 'm ' : ''}${sekunden}s`;
        
        return `<div class="active-buff"><span>${buff.name}</span> <span class="buff-timer">${zeitAnzeige}</span></div>`;
    }).join('');
    
    berechneGesamtWerte(); 
    aktualisiereAnzeigen();
}


// =========================================================
// 12. Haupt-Spielfunktionen
// =========================================================

function zeigeKlickFeedback(e) {
    const feedback = document.createElement('div');
    feedback.textContent = `+${kuerzeZahl(klickkraft)}`; 
    feedback.classList.add('klick-feedback');
    feedback.style.left = e.clientX + 'px';
    feedback.style.top = e.clientY + 'px';
    document.body.appendChild(feedback);

    setTimeout(() => { feedback.remove(); }, 800);
}

function klickKeks(e) {
    kekse += klickkraft;
    totalKlicks++; 
    
    aktualisiereAnzeigen();
    zeigeKlickFeedback(e);
    spieleSound(klickSound);
    pruefeAchievements();
    aktualisiereQuestAnzeige(); 
}

function kaufeUpgrade(upgradeID) {
    const upgrade = upgrades[upgradeID];
    
    if (upgrade.istEinmalig && upgrade.anzahl >= 1) return;

    if (kekse >= upgrade.kosten) {
        kekse -= upgrade.kosten; 
        upgrade.anzahl++;        
        spieleSound(kaufSound);

        if (upgrade.istEinmalig) {
            kpsMultiplikator *= upgrade.kpsMultiplikatorWert; 
        } else {
            upgrade.kosten = Math.floor(upgrade.basisKosten * Math.pow(upgrade.kostenSteigerung, upgrade.anzahl));
        }
        
        berechneGesamtWerte();
        aktualisiereAnzeigen();
        pruefeAchievements();
        aktualisiereQuestAnzeige(); 
    } 
}

function berechneGesamtWerte() {
    // 1. Basis-Werte setzen
    let klickfaktor = 1;
    let kpsZusatzMultiplikator = 1;

    // 2. Prestige und permanente Upgrades
    klickkraft = (1 + prestigeBonus); 
    klickkraft += upgrades.maus.anzahl * upgrades.maus.wirkung;

    kpsQuellen.oma = upgrades.oma.anzahl * upgrades.oma.kps;
    kpsQuellen.fabrik = upgrades.fabrik.anzahl * upgrades.fabrik.kps;
    let basisKPS = kpsQuellen.oma + kpsQuellen.fabrik;
    
    // 3. Temporäre Buffs anwenden
    activeBuffs.forEach(buff => {
        klickfaktor += buff.klickBonus; 
        kpsZusatzMultiplikator += buff.kpsBonus; 
    });

    // 4. Finale Berechnung
    klickkraft *= klickfaktor;
    
    let kpsNachPrestige = basisKPS * (1 + prestigeBonus);
    kekseProSekunde = kpsNachPrestige * kpsMultiplikator * kpsZusatzMultiplikator;
    
    klickkraft = Math.max(1, klickkraft);
    kekseProSekunde = Math.max(0, kekseProSekunde);
}


function aktualisiereAnzeigen() {
    const keksAnzahlGerundet = Math.floor(kekse);
    const neuePrestigeKekse = Math.floor(Math.sqrt(kekse / PRESTIGE_SCHWELLE));

    // Anzeigen
    keksZaehler.textContent = kuerzeZahl(keksAnzahlGerundet);
    
    const kpsBuffMulti = activeBuffs.reduce((acc, buff) => acc + buff.kpsBonus, 1);
    const totalMulti = Math.round(kpsMultiplikator * kpsBuffMulti);
    kpsAnzeige.textContent = `${kuerzeZahl(kekseProSekunde)} (x${totalMulti})`; 
    
    klickkraftAnzeige.textContent = kuerzeZahl(klickkraft);
    prestigeBonusAnzeige.textContent = `Prestige-Bonus: +${(prestigeBonus * 100).toFixed(1).replace('.0', '')}% (aus ${prestigeKekse} Keksen)`;

    // Prestige Button Zustand prüfen
    if (neuePrestigeKekse >= 1) {
        prestigeButton.disabled = false;
        prestigeButton.style.backgroundColor = '#2ecc71'; 
        prestigeButton.textContent = `Prestige (JETZT: +${neuePrestigeKekse})`;
    } else {
        prestigeButton.disabled = true;
        prestigeButton.style.backgroundColor = '#f39c12';
        prestigeButton.textContent = `Prestige (${kuerzeZahl(PRESTIGE_SCHWELLE - kekse)} bis Reset)`;
    }

    // Keks-Animation auslösen
    hauptKeks.classList.remove('keks-klick-animation'); 
    void hauptKeks.offsetWidth; 
    hauptKeks.classList.add('keks-klick-animation');

    document.title = `${kuerzeZahl(keksAnzahlGerundet)} Kekse - Mega-Keks-Klicker`; 
    
    // Shop-Anzeigen (Permanente Upgrades)
    document.querySelectorAll('.kauf-button').forEach(button => {
        const upgradeID = button.dataset.upgradeId;
        const upgrade = upgrades[upgradeID];
        const element = button.closest('.upgrade');
        
        element.querySelector('.kosten-anzeige').textContent = kuerzeZahl(Math.floor(upgrade.kosten));
        element.querySelector('.anzahl-anzeige').textContent = `Besitz: ${upgrade.anzahl}`;
        
        if (kekse >= upgrade.kosten && !(upgrade.istEinmalig && upgrade.anzahl >= 1)) {
            button.disabled = false;
            button.style.opacity = "1.0";
            element.classList.add('kaufbar');
        } else {
            button.disabled = true;
            button.style.opacity = "0.5";
            element.classList.remove('kaufbar');
        }
        
        if (upgrade.istEinmalig && upgrade.anzahl >= 1) {
            button.textContent = "VERFÜGUNG";
            element.classList.remove('kaufbar');
        } else {
             button.textContent = "Kaufen";
        }
    });
    
    // Shop-Anzeigen (Temporäre Buffs)
     document.querySelectorAll('.buff-kauf-button').forEach(button => {
        const buffID = button.dataset.buffId;
        const buffDef = buffDefinitions[buffID];
        const element = button.closest('.upgrade');
        
        element.querySelector('.kosten-anzeige').textContent = kuerzeZahl(Math.floor(buffDef.kosten));

        const istAktiv = activeBuffs.some(buff => buff.id === buffID);
        
        if (istAktiv) {
             button.disabled = true;
             button.textContent = 'LÄUFT!';
             element.classList.remove('kaufbar');
             return;
        }

        if (kekse >= buffDef.kosten) {
            button.disabled = false;
            button.style.opacity = "1.0";
            button.textContent = 'Starten';
            element.classList.add('kaufbar');
        } else {
            button.disabled = true;
            button.style.opacity = "0.5";
            button.textContent = 'Starten';
            element.classList.remove('kaufbar');
        }
    });
}

function gameLoop() {
    kekse += kekseProSekunde / 10;
    aktualisiereAnzeigen();
    aktualisiereBuffAnzeige(); 
    pruefeAchievements();
    aktualisiereQuestAnzeige(); 
}

// =========================================================
// 13. Event-Listener und Initialisierung
// =========================================================

hauptKeks.addEventListener('click', klickKeks);
speichernButton.addEventListener('click', speichereSpiel); 
resetButton.addEventListener('click', resetteSpiel);     
prestigeButton.addEventListener('click', prestigeReset); 

kpsAnzeige.addEventListener('mouseover', zeigeKpsTooltip);
kpsAnzeige.addEventListener('mouseout', versteckeKpsTooltip);

goldenerKeksButton.addEventListener('click', klickeGoldenenKeks);

document.querySelectorAll('.kauf-button').forEach(button => {
    button.addEventListener('click', () => {
        const upgradeID = button.dataset.upgradeId;
        kaufeUpgrade(upgradeID);
    });
});

document.querySelectorAll('.buff-kauf-button').forEach(button => {
    button.addEventListener('click', () => {
        const buffID = button.dataset.buffId;
        kaufeBuff(buffID);
    });
});

document.addEventListener('keydown', cheatCode);


// Automatisches Speichern und Game Loop starten
setInterval(speichereSpiel, 30000); 
ladeSpiel(); 
setInterval(gameLoop, 100);

startGoldenesKeksEvent();